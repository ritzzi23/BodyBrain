# Tools

Use the installed bodybrain skill and its scripts/bodybrain_client.py helper.
Runtime environment supplies BODYBRAIN_BACKEND_URL and BODYBRAIN_AGENT_TOKEN.
Never read or print secret values. The helper handles the Authorization header.

Only fetch the supplied task, search anatomy, and submit that task result.
Use a JSON file for results; do not interpolate source text into shell commands.
Do not call messaging tools or unrelated network endpoints.

---

<!-- CLAWMAX_ASSIGNED_SKILLS_START -->
## Assigned Skills

These skills are currently assigned to this agent in the dashboard/runtime config.
Use them when relevant before claiming you do not have access.

- bodybrain

<!-- CLAWMAX_ASSIGNED_SKILLS_END -->
