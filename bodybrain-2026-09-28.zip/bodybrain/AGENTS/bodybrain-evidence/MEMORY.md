# MEMORY.md

Use this file as the index for long-term notes. Daily notes live in `memory/YYYY-MM-DD.md`.
