import os
import json
import re
import urllib.request
import urllib.error

expected='https://tenant-39d3b3e0-8093-4101-968f-74e05bd785ac.aws.cognee.ai'
base=os.environ.get('COGNEE_BASE_URL','').rstrip('/')
key=os.environ.get('COGNEE_API_KEY','')

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        return None

if base != expected or not key:
    print(json.dumps({'status':'runtime_configuration_missing'}))
else:
    payload={'query':'BodyBrain integration check Cedar Lantern verification code','search_type':'CHUNKS','datasets':['bodybrain_clawmax_test'],'top_k':3}
    req=urllib.request.Request(base+'/api/v1/search',data=json.dumps(payload).encode(),headers={'X-Api-Key':key,'Content-Type':'application/json'},method='POST')
    try:
        with urllib.request.build_opener(NoRedirect).open(req,timeout=30) as response:
            result=json.loads(response.read(131073))
        codes=sorted(set(re.findall(r'BB-[a-f0-9]{24}',json.dumps(result))))
        print(json.dumps({'status':'retrieved' if codes else 'no_match','verification_codes':codes}))
    except urllib.error.HTTPError as error:
        print(json.dumps({'status':'http_error','http_status':error.code}))
    except Exception as error:
        print(json.dumps({'status':'request_failed','error_type':type(error).__name__}))
