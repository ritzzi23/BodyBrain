import json, os

path = os.path.expanduser('~/.openclaw/openclaw.json')

with open(path) as f:
    config = json.load(f)

plugins = config.get('plugins', {})
allow = plugins.get('allow', [])
deny = plugins.get('deny', [])
cognee = plugins.get('entries', {}).get('cognee-openclaw', {})
slots = plugins.get('slots', {})
cognee_cfg = cognee.get('config', {})
env = os.environ

print('allow_cognee_openclaw:', 'cognee-openclaw' in allow)
print('deny_cognee_openclaw:', 'cognee-openclaw' in deny)
print('cognee_enabled:', cognee.get('enabled', None))
print('slots_memory:', bool(slots.get('memory', False)))
print('datasetName:', cognee_cfg.get('datasetName', None))
print('autoIndex:', cognee_cfg.get('autoIndex', None))
print('autoRecall:', cognee_cfg.get('autoRecall', None))
print('captureSession:', cognee_cfg.get('captureSession', None))
print('enableSessions:', cognee_cfg.get('enableSessions', None))
print('env_COGNEE_API_KEY:', 'COGNEE_API_KEY' in env)
print('env_COGNEE_BASE_URL:', 'COGNEE_BASE_URL' in env)
